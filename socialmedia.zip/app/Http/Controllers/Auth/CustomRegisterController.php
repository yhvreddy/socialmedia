<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Http\Controllers\DefaultController;
use App\DefaultModel;
class CustomRegisterController extends DefaultController
{


    public function __construct()
    {
        $this->default = new DefaultModel;
    }
    
    public function saveRegData(Request $request)
    {
        $data = $this->default->saveregdata($request);
        //echo json_decode($data);
        print_r($data);
    }

}
